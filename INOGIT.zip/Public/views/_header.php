<link rel="stylesheet" type="text/css" href="/INOGIT/Public/assets/css/bootstrap.min.css">
<script type="text/javascript" src="/INOGIT/Public/assets/js/jquery.min.js"></script>
<script type="text/javascript" src="/INOGIT/Public/assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
 
<link rel="stylesheet" type="text/css" href="/INOGIT/Public/assets/css/style.css">
<script type="text/javascript" src="/INOGIT/Public/assets/js/js.js"></script> 