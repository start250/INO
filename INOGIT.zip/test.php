<?php
$str="nameoffile.pdf";

echo mysqli_real_escape_string("bdsa");