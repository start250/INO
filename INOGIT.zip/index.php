<script type="text/javascript">
	location.href='dashboard.php';
</script>