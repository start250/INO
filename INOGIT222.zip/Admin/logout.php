<?php
session_start();
unset($_SESSION['admin']);
?>
<script type="text/javascript">location.href='login.php'</script>