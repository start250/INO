<script type="text/javascript" src="/INOGIT/Public/assets/js/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script type="text/javascript" src="/INOGIT/Public/assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/INOGIT/Public/assets/js/mdb.min.js"></script>
<script type="text/javascript" src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>

</body>